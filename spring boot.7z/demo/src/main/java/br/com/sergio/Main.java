package br.com.sergio;

import br.com.sergio.customer.DAO.repository.CustomerRepository;
import br.com.sergio.customer.domain.Customer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication

public class Main {

    public static void main(String[] args) {

        ConfigurableApplicationContext run = SpringApplication.run(Main.class, args);

        String[] beanDefinitionNames =
                run.getBeanDefinitionNames();

//        for (String beanDefinitionName : beanDefinitionNames) {
//            System.out.println(beanDefinitionName);
//        }
    }

//    @Bean
//    CommandLineRunner runner(CustomerRepository customerRepository) {
//        return args -> {
//            Customer sergio = new Customer(
//                    "Sergio",
//                    "sergio@gmail.com",
//                    63
//            );
//            Customer junior = new Customer(
//                    "Junior",
//                    "junior@gmail.com",
//                    26
//            );
//            List<Customer> customers = List.of(sergio, junior);
//            customerRepository.saveAll(customers);
//        };
//
//    }

}
