package br.com.sergio.customer.controller;

import br.com.sergio.customer.controller.request.CustomerRegistrationRequest;
import br.com.sergio.customer.controller.request.CustomerUpdateRequest;
import br.com.sergio.customer.domain.Customer;
import br.com.sergio.customer.service.CustomerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/customers")
@CrossOrigin
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public ResponseEntity<List<Customer>> getCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }

    @GetMapping(
            path = "{id}"
    )
    public Customer getCustomer(
            @PathVariable(name = "id") Integer id
    ) {
        return customerService.getCustomerById(id);
    }

    @PostMapping
    public void registerCustomer(
            @RequestBody CustomerRegistrationRequest request
    ) {
        customerService.addCustomer(request);
    }

    @DeleteMapping(
            path = "{id}"
    )
    public void deleteCustomer(
            @PathVariable(name = "id") Integer id
    ) {
        customerService.deleteCustomerById(id);
    }
    @PutMapping(
            path = "{id}"
    )
    public void updateCustomer(
            @PathVariable(name = "id") Integer id,
            @RequestBody CustomerUpdateRequest updateRequest
    ) {
        customerService.updateCustomer(id, updateRequest);
    }
}



