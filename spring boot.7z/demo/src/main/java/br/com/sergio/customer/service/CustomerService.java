package br.com.sergio.customer.service;

import br.com.sergio.customer.DAO.CustomerDAO;
import br.com.sergio.customer.controller.request.CustomerRegistrationRequest;
import br.com.sergio.customer.controller.request.CustomerUpdateRequest;
import br.com.sergio.customer.domain.Customer;
import br.com.sergio.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerDAO customerDAO;

    public CustomerService(CustomerDAO customerDAO) {
        this.customerDAO = customerDAO;
    }

    public List<Customer> getAllCustomers() {
        return customerDAO.selectAllCustomers();
    }

    public Customer getCustomerById(Integer id) {
        return customerDAO.selectCustomerById(id)
                .orElseThrow(
                        () -> new ResourceNotFoundException(
                                "Customer with this id [%s] not found"
                        )
                );
    }

    public void addCustomer(
            CustomerRegistrationRequest request
    ) {
        Customer customer = new Customer(
                request.getName(),
                request.getEmail(),
                request.getPassword(),
                request.getAge()
        );
        customerDAO.insertCustomer(customer);
    }

    public void deleteCustomerById(Integer id) {
        if (!customerDAO.existsPersonWithId(id)) {
            throw new ResourceNotFoundException(
                    "Customer with this id [%s] not found"
            );
        }

        customerDAO.deleteCustomerById(id);
    }

    public void updateCustomer(Integer id, CustomerUpdateRequest updateRequest) {

        Customer customer = getCustomerById(id);

        boolean changes = false;

        if (
                updateRequest.getName() != null && !updateRequest.getName().equals(customer.getName())
        ) {
            customer.setName(updateRequest.getName());
            customerDAO.insertCustomer(customer);
            changes = true;
        }

        if (
                updateRequest.getAge() != null && !updateRequest.getAge().equals(customer.getAge())
        ) {
            customer.setAge(updateRequest.getAge());
            customerDAO.updateCustomer(customer);
            changes = true;
        }

        if(!changes) {

        }
    }

}
