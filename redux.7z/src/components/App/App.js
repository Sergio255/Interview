import { useDispatch, useSelector } from "react-redux";

import { createUser } from "../../redux/user/slice";
import rootReducer from "../../redux/root-reducer";

export function App() {
  const dispatch = useDispatch();

  const { user } = useSelector((rootReducer) => rootReducer.user);

  dispatch(
    createUser({
      name: "Júnior",
      email: "sergio.junior@gmail.com",
    })
  );

  return (
    <h1>
      <div>Olá {user ? user.name : "Visitante"}, bem vindo</div>
    </h1>
  );
}

export default App;
