import { createContext, useState } from "react";
import api from "../services/api";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

export const AuthContext = createContext({});

function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(false);
  const navigate = useNavigate();

  function signIn(email, password) {
    console.log(email);
    console.log(password);
    toast.warn("Logado com sucesso");
  }

  async function signUp(name, email, password, age) {
    setLoadingAuth(true);
    const userData = {
      name: name,
      email: email,
      password: password,
      age: null,
    };
    console.log(userData);
    await api.post("customers", userData).then(async (response) => {
      console.log(response.data);
      let data = {
        name: name,
        email: email,
        age: null,
      };

      setUser(data);
      storageUser(data);
      setLoadingAuth(false);
      toast.success("Customer inserted with success !");
      navigate("/dashboard");
    });
  }

  function storageUser(data) {
    localStorage.setItem("@customer", JSON.stringify(data));
  }

  return (
    <AuthContext.Provider
      value={{
        signed: !!user, // false
        user,
        signIn,
        signUp,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export default AuthProvider;
