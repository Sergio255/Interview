import "./signin.css";
import logo from "../../assets/logo.png";
import { useContext, useRef } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../../contexts/auth";

export default function SignIn() {
  // Using useRef just to show Performance stuffs
  const emailRef = useRef(null);
  const passwordRef = useRef(null);

  const { signIn } = useContext(AuthContext);

  async function handleSignIn(e) {
    e.preventDefault();
    console.log({
      email: emailRef.current?.value,
    });
    if (emailRef !== "" && passwordRef !== "") {
      signIn(emailRef, passwordRef);
    }
  }

  return (
    <div className="container-center">
      <div className="login">
        <div className="login-area">
          <img src={logo} alt="System Logo " />
        </div>

        <form onSubmit={handleSignIn}>
          <input type="text" placeholder="email@email.com" ref={emailRef} />
          <input type="password" placeholder="*********" ref={passwordRef} />

          <button type="submit">Access</button>
        </form>

        <Link to="/register">Create an account</Link>
      </div>
    </div>
  );
}
